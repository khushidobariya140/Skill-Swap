"""SkillSwap - find teammates by skill. Flask + SQLite. Groq is optional (used for 3 small helpers)."""
import os, re, csv, json, time, ssl, secrets, sqlite3, urllib.request, urllib.error
from functools import wraps
from flask import (Flask, g, render_template, request, redirect, url_for,
                   session, flash, abort, jsonify)
from werkzeug.security import generate_password_hash, check_password_hash

BASE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(BASE, "skillswap.db")

try:
    import certifi
    SSL_CTX = ssl.create_default_context(cafile=certifi.where())
except Exception:
    SSL_CTX = ssl.create_default_context()
ENV_SOURCE = None
def load_env():
    """Reads .env (also .env.txt, which Windows Notepad creates by mistake). Handles BOM, quotes and spaces."""
    global ENV_SOURCE
    for name in (".env", ".env.txt", ".env.example"):
        p = os.path.join(BASE, name)
        if not os.path.exists(p): continue
        found = False
        for line in open(p, encoding="utf-8-sig", errors="ignore"):
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line: continue
            k, v = line.split("=", 1)
            k, v = k.replace("export ", "").strip(), v.strip().strip("\"'").strip()
            if v and k == "GROQ_API_KEY": found = True
            if v: os.environ[k] = v
        if found:
            ENV_SOURCE = name; break
load_env()

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-before-deploying")
SECTORS = ["Tech / SaaS", "E-commerce", "Food & delivery", "Health", "Fintech", "Education",
           "Social", "Media", "Travel", "Transport", "Hardware", "Services", "Other"]

SCHEMA = """
create table if not exists users(id integer primary key, name text not null, email text unique not null,
  pw text not null, college text default '', bio text default '', hours integer default 5);
create table if not exists user_skills(user_id integer references users(id) on delete cascade,
  skill text, level integer default 1, primary key(user_id, skill));
create table if not exists projects(id integer primary key, owner_id integer references users(id),
  title text, pitch text, sector text, lessons text, stack text, created text default current_timestamp);
create table if not exists needs(project_id integer references projects(id) on delete cascade,
  skill text, level integer default 1, primary key(project_id, skill));
create table if not exists members(project_id integer references projects(id) on delete cascade,
  user_id integer references users(id), status text default 'invited', primary key(project_id, user_id));
create table if not exists messages(id integer primary key, sender integer, receiver integer,
  body text, seen integer default 0, created text default current_timestamp);
"""

def init_db():
    c = sqlite3.connect(DB); c.executescript(SCHEMA)
    if "stack" not in [r[1] for r in c.execute("pragma table_info(projects)")]:   # upgrade older databases
        c.execute("alter table projects add column stack text")
    c.commit(); c.close()

# ---------- database helpers ----------
def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB); g.db.row_factory = sqlite3.Row
        g.db.execute("pragma foreign_keys=on")
    return g.db

@app.teardown_appcontext
def close_db(_):
    d = g.pop("db", None)
    if d: d.close()

def q(sql, args=(), one=False):
    rows = db().execute(sql, args).fetchall()
    return (rows[0] if rows else None) if one else rows

def run(sql, args=()):
    cur = db().execute(sql, args); db().commit(); return cur.lastrowid

# ---------- skills ----------
ALIASES = {"js": "javascript", "reactjs": "react", "nodejs": "node.js", "node": "node.js", "ui/ux": "ui design",
           "ui": "ui design", "ux": "ux design", "ml": "machine learning", "py": "python", "golang": "go"}

def norm(s):
    s = re.sub(r"\s+", " ", (s or "").strip().lower())
    return ALIASES.get(s, s)

def toint(v, d, lo, hi):
    try: return max(lo, min(hi, int(v)))
    except (TypeError, ValueError): return d

def parse_skills(text, default=1):   # "python:2, ui design" -> [("python",2),("ui design",1)]
    out = {}
    for part in re.split(r"[,\n]", text or ""):
        name, _, lv = part.partition(":"); name = norm(name)
        if name and len(name) <= 40: out[name] = toint(lv, default, 1, 3)
    return list(out.items())

def my_skills():
    if not g.user: return {}
    return {r["skill"]: r["level"] for r in q("select skill, level from user_skills where user_id=?", (g.user["id"],))}

# ---------- matching engine (plain rules, no ML) ----------
def card(p, mine=None):
    """Everything the UI needs about a project: which needs are filled by team members and which are open."""
    needs = q("select skill, level from needs where project_id=? order by rowid", (p["id"],))
    members = q("select u.id, u.name from members m join users u on u.id=m.user_id "
                "where m.project_id=? and m.status='joined' order by m.rowid", (p["id"],))
    covered = {}
    for m in members:
        for s in q("select skill from user_skills where user_id=?", (m["id"],)):
            covered.setdefault(s["skill"], m)
    open_ = [n["skill"] for n in needs if n["skill"] not in covered]
    owner = q("select name from users where id=?", (p["owner_id"],), one=True)["name"]
    return dict(p=p, owner=owner, members=members, needs=needs, open=open_,
                filled=[dict(skill=n["skill"], by=covered[n["skill"]]) for n in needs if n["skill"] in covered],
                can_fill=[s for s in open_ if mine and s in mine])

def find_matches(c):
    """Score every user on the OPEN needs only. 85% skill fit (level-aware) + 15% weekly availability."""
    open_needs = [n for n in c["needs"] if n["skill"] in c["open"]]
    if not open_needs: return []
    taken = {m["user_id"] for m in q("select user_id from members where project_id=?", (c["p"]["id"],))}
    out = []
    for u in q("select * from users"):
        if u["id"] in taken: continue
        sk = {r["skill"]: r["level"] for r in q("select skill, level from user_skills where user_id=?", (u["id"],))}
        credit, fills = 0.0, []
        for n in open_needs:
            if n["skill"] in sk:
                credit += 0.6 + 0.4 * min(sk[n["skill"]] / n["level"], 1)   # having it = 60%, level match = up to 40%
                fills.append(n["skill"])
        if fills:
            fit = credit / len(open_needs)
            out.append(dict(u=u, fills=fills, pct=round(100 * (0.85 * fit + 0.15 * min(u["hours"] / 10, 1)))))
    return sorted(out, key=lambda m: -m["pct"])

# ---------- failed-startup dataset ----------
_FAIL = []
def failures():
    if not _FAIL:
        with open(os.path.join(BASE, "data", "failed_startups.csv"), encoding="utf-8") as f:
            _FAIL.extend(csv.DictReader(f, delimiter="|"))
    return _FAIL

def similar_failures(sector, text, k=3):
    words = set(re.findall(r"[a-z]{4,}", text.lower()))
    def score(r):
        bag = set(re.findall(r"[a-z]{4,}", (r["tags"] + " " + r["what_it_did"]).lower()))
        return (4 if r["sector"] == sector else 0) + len(words & bag)
    return sorted(failures(), key=score, reverse=True)[:k]

# ---------- Groq (optional; every call has a fallback, and the real error is shown to the user) ----------
AI_LAST = {"error": None, "log": []}

# Groq retired the Llama 3.x models on 16 Aug 2026. These are the current replacements; GROQ_MODEL in .env goes first.
DEFAULT_MODELS = ["openai/gpt-oss-20b", "openai/gpt-oss-120b", "qwen/qwen3.6-27b"]

def _post_groq(key, model, messages, json_mode, max_tokens, extra):
    # reasoning models spend part of max_tokens on thinking, so always leave generous room
    body = {"model": model, "messages": messages, "temperature": 0.4, "max_tokens": max(max_tokens, 1500), **extra}
    if json_mode: body["response_format"] = {"type": "json_object"}
    req = urllib.request.Request("https://api.groq.com/openai/v1/chat/completions", json.dumps(body).encode(),
          {"Content-Type": "application/json", "Authorization": "Bearer " + key, "User-Agent": "skillswap/1.3"})
    with urllib.request.urlopen(req, timeout=30, context=SSL_CTX) as r:
        text = json.loads(r.read())["choices"][0]["message"].get("content") or ""
    return re.sub(r"<think>.*?</think>", "", text, flags=re.S).strip()

def _chat_models(key):
    """Asks Groq which chat models this key can use right now (names change over time)."""
    req = urllib.request.Request("https://api.groq.com/openai/v1/models", headers={"Authorization": "Bearer " + key, "User-Agent": "skillswap/1.3"})
    try:
        with urllib.request.urlopen(req, timeout=15, context=SSL_CTX) as r:
            ids = [m["id"] for m in json.loads(r.read())["data"]]
    except Exception as e:
        AI_LAST["log"].append(f"Could not list models: {e}"); return []
    bad = ("whisper", "guard", "safeguard", "tts", "playai", "orpheus", "embed", "compound")
    good = [i for i in ids if not any(w in i for w in bad)]
    AI_LAST["log"].append("Models your key can use: " + ", ".join(good[:12]))
    return sorted(good, key=lambda i: 0 if ("gpt-oss" in i or "qwen" in i or "llama" in i) else 1)[:8]

def groq(messages, json_mode=False, max_tokens=500):
    """Returns the model text, or None. The reason for a failure is kept in AI_LAST['error'], every attempt in AI_LAST['log']."""
    key = os.environ.get("GROQ_API_KEY", "").strip()
    AI_LAST["error"], AI_LAST["log"] = None, []
    if not key:
        AI_LAST["error"] = "No GROQ_API_KEY found. Put it in the .env file next to app.py, then restart the app."
        return None
    candidates = [m for m in [os.environ.get("GROQ_MODEL", "").strip()] + DEFAULT_MODELS if m]
    tried, listed = set(), False
    while True:
        for model in [m for m in dict.fromkeys(candidates) if m not in tried]:
            tried.add(model)
            for use_json in ([True, False] if json_mode else [False]):
                for extra in ([{"reasoning_effort": "low"}, {}] if "gpt-oss" in model else [{}]):
                    try:
                        text = _post_groq(key, model, messages, use_json, max_tokens, extra)
                        if text:
                            AI_LAST["log"].append(f"{model}: worked"); return text
                        AI_LAST["error"] = f"{model} returned an empty reply."
                    except urllib.error.HTTPError as e:
                        try: detail = json.loads(e.read())["error"]["message"]
                        except Exception: detail = e.reason
                        AI_LAST["error"] = f"Groq error {e.code} with model {model}: {detail}"
                        if e.code == 401:
                            AI_LAST["error"] = "Groq rejected the API key (401). Copy a fresh key from console.groq.com with no spaces or quotes."; return None
                        if e.code == 429:
                            AI_LAST["error"] = "Groq rate limit reached (429). Wait a minute and try again."; return None
                    except Exception as e:
                        AI_LAST["error"] = f"Could not reach Groq ({e}). Check your internet, or try a mobile hotspot if your college Wi-Fi blocks it."
                        return None
                    AI_LAST["log"].append(f"{model}: {AI_LAST['error']}")
        if listed: return None
        listed = True; candidates = _chat_models(key)
        if not [m for m in candidates if m not in tried]: return None

def parse_json(text):
    return json.loads(re.search(r"\{.*\}", text or "", re.S).group(0))   # ignores ```json fences around the reply

def fallback_stack(text):
    """Rule-based suggestion used when the AI is unavailable, so the feature never shows an empty box."""
    t = set(re.findall(r"[a-z]+", text.lower()))
    mobile, ai = t & {"app", "android", "ios", "mobile"}, t & {"ai", "ml", "predict", "detect", "recommend", "model", "vision", "image", "chatbot", "nlp"}
    st = [("Frontend", "Flutter" if mobile else "HTML, CSS and JavaScript",
           "One codebase for Android and iOS, free to use" if mobile else "No setup needed and enough for a first version"),
          ("Backend", "Python with Flask", "Small, easy to learn and quick to build APIs"),
          ("Database", "SQLite, later PostgreSQL", "SQLite needs no setup; switch when you have many users")]
    if ai: st.append(("AI / data", "scikit-learn or the Groq API", "Start with a simple model or a hosted LLM before training your own"))
    if t & {"payment", "payments", "pay", "wallet"}: st.append(("Payments", "Razorpay test mode", "Popular in India with a free sandbox"))
    if t & {"map", "maps", "location", "nearby", "delivery"}: st.append(("Maps", "OpenStreetMap with Leaflet", "Free alternative to Google Maps"))
    st.append(("Hosting", "Render or PythonAnywhere free tier", "Free and simple for a Flask app"))
    skills = ["mobile development:2" if mobile else "frontend:2", "backend:2", "ui design:1"] + (["machine learning:2"] if ai else []) + ["marketing:1"]
    return dict(summary="A simple, free-to-start stack that students can build and explain.", ai=False,
                stack=[dict(layer=a, tech=b, why=c) for a, b, c in st], skills=skills,
                steps=["Build one core feature first", "Show it to five real users", "Fix the biggest problem they report"])

def suggest_stack(title, pitch, sector):
    out = groq([{"role": "system", "content": "You are a pragmatic tech lead advising students with no budget. Given a startup idea, recommend a "
        "beginner-friendly stack that is free to start. Reply only with JSON: "
        '{"summary":"one sentence","stack":[{"layer":"Frontend","tech":"React","why":"max 15 words"}],'
        '"skills":[{"name":"backend","level":2}],"steps":["short first step"]}. '
        "4 to 6 layers chosen from Frontend, Backend, Database, AI / data, Hosting, Extras. skills are the 3 to 6 team skills needed "
        "(lowercase short names, level 1 to 3). steps has 3 short first steps."},
        {"role": "user", "content": f"Title: {title}\nSector: {sector}\nIdea: {pitch}"}], json_mode=True, max_tokens=800)
    try:
        d = parse_json(out)
        stack = [dict(layer=str(i["layer"])[:30], tech=str(i["tech"])[:90], why=str(i.get("why", ""))[:160]) for i in d["stack"]][:7]
        skills = [f"{norm(i['name'])}:{toint(i.get('level'), 1, 1, 3)}" for i in d["skills"]][:6]
        if stack and skills:
            return dict(summary=str(d.get("summary", ""))[:240], stack=stack, skills=skills, ai=True, error=None,
                        steps=[str(x)[:140] for x in d.get("steps", [])][:4])
    except Exception:
        if out: AI_LAST["error"] = "The AI replied in an unexpected format. Try again."
    fb = fallback_stack(f"{title} {pitch} {sector}"); fb["error"] = AI_LAST["error"]
    return fb

VOCAB = {"app": "mobile development", "android": "mobile development", "ios": "mobile development",
         "website": "frontend", "web": "frontend", "design": "ui design", "ui": "ui design", "ux": "ux design",
         "backend": "backend", "api": "backend", "database": "databases", "payment": "backend",
         "ai": "machine learning", "ml": "machine learning", "model": "machine learning", "data": "data analysis",
         "market": "marketing", "marketing": "marketing", "social": "marketing", "sell": "marketing",
         "video": "video editing", "content": "content writing", "finance": "finance", "legal": "legal",
         "hardware": "electronics", "sensor": "electronics", "iot": "electronics"}

def extract_skills(idea):
    out = groq([{"role": "system", "content": 'Turn a startup idea into the skills needed to build a first version. '
        'Reply only with JSON: {"skills":[{"name":"python","level":2}]}. 3 to 6 skills, lowercase short names like '
        'python, ui design, marketing, mobile development, data analysis. level: 1 beginner ok, 2 comfortable, 3 strong.'},
        {"role": "user", "content": idea}], json_mode=True)
    try:
        res = [f"{norm(i['name'])}:{toint(i.get('level'), 1, 1, 3)}" for i in parse_json(out)["skills"]][:6]
        if res: return res, True
    except Exception: pass
    words = set(re.findall(r"[a-z]+", idea.lower()))
    found = list(dict.fromkeys(s for w, s in VOCAB.items() if w in words))
    return [f"{s}:1" for s in found[:5]] or ["business:1", "frontend:1"], False

def draft_opener(sender, to, project, fills):
    ctx = f"Sender: {sender}. Recipient: {to['name']}. Project: {project['title'] if project else 'none'}. " \
          f"Recipient's relevant skills: {', '.join(fills) or 'unknown'}."
    txt = groq([{"role": "system", "content": "Write a friendly 2-3 sentence first message from one student to another, "
        "inviting a chat about a startup project. Mention one specific skill of theirs. No emojis."},
        {"role": "user", "content": ctx}], max_tokens=150)
    if txt: return txt.strip()
    first = to["name"].split()[0]
    if project:
        return (f"Hi {first}, I'm building \"{project['title']}\" and need someone with {', '.join(fills) or 'your skills'}. "
                "I saw it on your profile. Would you be up for a quick chat about it?")
    return f"Hi {first}, I saw your profile on SkillSwap and liked your skills. Are you working on anything right now?"

def lessons_for(p):
    """Three similar failed startups + what to avoid. Groq only rewrites the dataset rows, so nothing is invented."""
    if p["lessons"]: return json.loads(p["lessons"])
    rows = similar_failures(p["sector"], p["title"] + " " + p["pitch"])
    out = groq([{"role": "system", "content": 'Use ONLY the supplied failed-startup records. For each, write one sentence '
        '(max 25 words) telling the founder of the new idea what to avoid. Reply only with JSON: '
        '{"items":[{"name":"...","avoid":"..."}]}'},
        {"role": "user", "content": json.dumps({"new_idea": p["pitch"], "records": [
            {k: r[k] for k in ("name", "why_it_failed", "lesson")} for r in rows]})}], json_mode=True)
    try: avoid = {i["name"]: i["avoid"] for i in parse_json(out)["items"]}
    except Exception: avoid = None
    items = [dict(r, avoid=(avoid or {}).get(r["name"], r["lesson"])) for r in rows]
    if avoid: run("update projects set lessons=? where id=?", (json.dumps(items), p["id"]))
    return items

# ---------- auth, csrf, template helpers ----------
def login_required(f):
    @wraps(f)
    def w(*a, **k):
        if not g.user:
            flash("Log in to continue."); return redirect(url_for("login", next=request.path))
        return f(*a, **k)
    return w

@app.before_request
def load_user():
    g.user = q("select * from users where id=?", (session["uid"],), one=True) if "uid" in session else None
    if request.method == "POST":
        tok = request.form.get("csrf") or request.headers.get("X-CSRF")
        if not tok or tok != session.get("csrf"): abort(400, "Your form expired. Reload the page and try again.")

@app.context_processor
def inject():
    session.setdefault("csrf", secrets.token_hex(16))
    unread = invites = 0
    if g.user:
        unread = q("select count(*) c from messages where receiver=? and seen=0", (g.user["id"],), one=True)["c"]
        invites = q("select count(*) c from members where user_id=? and status='invited'", (g.user["id"],), one=True)["c"]
    last = q("select coalesce(max(id),0) m from messages where receiver=?", (g.user["id"],), one=True)["m"] if g.user else 0
    return dict(csrf=session["csrf"], me=g.user, notif=unread + invites, last_msg=last,
                ai_ready=bool(os.environ.get("GROQ_API_KEY", "").strip()))

@app.template_filter("avcolor")
def avcolor(i): return ["#1F5A43", "#6B2D5C", "#B5482A", "#8A6A12", "#3F6B22", "#A33A5B"][i % 6]

@app.template_filter("lvl")
def lvl(n): return {1: "Beginner", 2: "Comfortable", 3: "Strong"}.get(n, "")

def get_project(pid):
    p = q("select * from projects where id=?", (pid,), one=True)
    if not p: abort(404)
    return p

# ---------- pages ----------
@app.route("/")
def home():
    mine = my_skills()
    rows = q("select * from projects order by id desc limit 6")
    stats = dict(users=q("select count(*) c from users", one=True)["c"], projects=q("select count(*) c from projects", one=True)["c"])
    return render_template("home.html", cards=[card(p, mine) for p in rows], stats=stats)

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        f = request.form; name = f.get("name", "").strip(); email = f.get("email", "").strip().lower()
        err = None
        if not name or "@" not in email or len(f.get("password", "")) < 6:
            err = "Enter your name, a valid email and a password of at least 6 characters."
        elif q("select 1 from users where email=?", (email,), one=True):
            err = "That email is already registered. Try logging in."
        if err:
            flash(err); return render_template("auth.html", mode="register"), 400
        uid = run("insert into users(name,email,pw,college) values(?,?,?,?)",
                  (name, email, generate_password_hash(f["password"]), f.get("college", "").strip()))
        session.clear(); session["uid"] = uid
        flash("Welcome! Add your skills so project owners can find you.")
        return redirect(url_for("profile"))
    return render_template("auth.html", mode="register")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        u = q("select * from users where email=?", (request.form.get("email", "").strip().lower(),), one=True)
        if u and check_password_hash(u["pw"], request.form.get("password", "")):
            session.clear(); session["uid"] = u["id"]
            nxt = request.args.get("next", "")
            return redirect(nxt if nxt.startswith("/") and not nxt.startswith("//") else url_for("projects"))
        flash("Email or password is incorrect."); return render_template("auth.html", mode="login"), 400
    return render_template("auth.html", mode="login")

@app.post("/logout")
def logout():
    session.clear(); return redirect(url_for("home"))

@app.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    uid = g.user["id"]
    if request.method == "POST":
        f = request.form; a = f.get("action")
        if a == "save":
            run("update users set name=?, college=?, bio=?, hours=? where id=?",
                (f.get("name", "").strip() or g.user["name"], f.get("college", "").strip(),
                 f.get("bio", "").strip()[:400], toint(f.get("hours"), 5, 0, 40), uid))
            flash("Profile saved.")
        elif a == "add":
            for s, l in parse_skills(f.get("skills", ""), toint(f.get("level"), 1, 1, 3)):
                run("insert or replace into user_skills values(?,?,?)", (uid, s, l))
        elif a == "remove":
            run("delete from user_skills where user_id=? and skill=?", (uid, f.get("skill", "")))
        return redirect(url_for("profile"))
    skills = q("select skill, level from user_skills where user_id=? order by level desc, skill", (uid,))
    return render_template("profile.html", skills=skills)

@app.route("/u/<int:uid>")
def user(uid):
    u = q("select * from users where id=?", (uid,), one=True) or abort(404)
    skills = q("select skill, level from user_skills where user_id=? order by level desc, skill", (uid,))
    mine = my_skills()
    projs = [card(p, mine) for p in q("select * from projects where owner_id=? order by id desc", (uid,))]
    return render_template("user.html", u=u, skills=skills, cards=projs)

@app.route("/people")
def people():
    s = norm(request.args.get("skill", "")); out = []
    for u in q("select * from users order by id desc"):
        if g.user and u["id"] == g.user["id"]: continue
        sk = q("select skill, level from user_skills where user_id=? order by level desc", (u["id"],))
        if s and not any(s in r["skill"] for r in sk): continue
        out.append(dict(u=u, skills=sk))
    return render_template("people.html", people=out, skill=request.args.get("skill", ""))

@app.route("/projects")
def projects():
    sector, term = request.args.get("sector", ""), request.args.get("q", "").strip().lower()
    mine = my_skills(); cards = []
    for p in q("select * from projects order by id desc"):
        if sector and p["sector"] != sector: continue
        c = card(p, mine)
        if term and term not in (p["title"] + " " + p["pitch"] + " " + " ".join(n["skill"] for n in c["needs"])).lower(): continue
        cards.append(c)
    return render_template("projects.html", cards=cards, sectors=SECTORS, sector=sector, term=term)

@app.route("/projects/new", methods=["GET", "POST"])
@login_required
def project_new():
    if request.method == "POST":
        f = request.form; title, pitch = f.get("title", "").strip(), f.get("pitch", "").strip()
        needs = parse_skills(f.get("needs", ""), 1)
        sector = f.get("sector") if f.get("sector") in SECTORS else "Other"
        if not title or not pitch or not needs:
            flash("Add a title, a short pitch and at least one skill you need.")
            return render_template("project_new.html", sectors=SECTORS, f=f), 400
        try:
            st = json.loads(f.get("stack", "")); st = st if isinstance(st.get("stack"), list) else None
        except (ValueError, AttributeError): st = None
        pid = run("insert into projects(owner_id,title,pitch,sector,stack) values(?,?,?,?,?)",
                  (g.user["id"], title[:90], pitch[:800], sector, json.dumps(st) if st else None))
        for s, l in needs: run("insert into needs values(?,?,?)", (pid, s, l))
        run("insert into members values(?,?,'joined')", (pid, g.user["id"]))
        return redirect(url_for("project", pid=pid))
    return render_template("project_new.html", sectors=SECTORS, f={})

@app.route("/projects/<int:pid>")
def project(pid):
    p = get_project(pid); c = card(p, my_skills())
    owner = bool(g.user and g.user["id"] == p["owner_id"])
    status = {r["user_id"]: r["status"] for r in q("select user_id, status from members where project_id=?", (pid,))}
    pending = q("select u.id, u.name from members m join users u on u.id=m.user_id where m.project_id=? and m.status='invited'", (pid,))
    return render_template("project.html", c=c, p=p, owner=owner, matches=find_matches(c) if owner else [],
                           pending=pending, stack=json.loads(p["stack"]) if p["stack"] else None, mystatus=status.get(g.user["id"]) if g.user else None, lessons=lessons_for(p))

@app.post("/projects/<int:pid>/invite/<int:uid>")
@login_required
def invite(pid, uid):
    p = get_project(pid)
    if p["owner_id"] != g.user["id"]: abort(403)
    if not q("select 1 from members where project_id=? and user_id=?", (pid, uid), one=True):
        run("insert into members values(?,?,'invited')", (pid, uid))
        run("insert into messages(sender,receiver,body) values(?,?,?)", (g.user["id"], uid,
            f'I invited you to join the team for "{p["title"]}". Open the project page to accept or decline.'))
        flash("Invitation sent.")
    return redirect(url_for("project", pid=pid))

@app.post("/projects/<int:pid>/respond")
@login_required
def respond(pid):
    if not q("select 1 from members where project_id=? and user_id=? and status=?", (pid, g.user["id"], "invited"), one=True): abort(404)
    if request.form.get("choice") == "accept":
        run("update members set status='joined' where project_id=? and user_id=?", (pid, g.user["id"])); flash("You joined the team.")
    else:
        run("delete from members where project_id=? and user_id=?", (pid, g.user["id"])); flash("Invitation declined.")
    return redirect(url_for("project", pid=pid))

@app.route("/messages")
@login_required
def inbox():
    me = g.user["id"]
    convos = q("""select u.id, u.name, m.body, m.created,
        (select count(*) from messages x where x.sender=u.id and x.receiver=? and x.seen=0) unread
        from users u join messages m on m.id=(select max(id) from messages
        where (sender=u.id and receiver=?) or (sender=? and receiver=u.id))
        where u.id!=? order by m.id desc""", (me, me, me, me))
    invites = q("select p.id, p.title, u.name owner from members m join projects p on p.id=m.project_id "
                "join users u on u.id=p.owner_id where m.user_id=? and m.status='invited'", (me,))
    return render_template("messages.html", convos=convos, invites=invites)

@app.route("/messages/<int:uid>", methods=["GET", "POST"])
@login_required
def thread(uid):
    me = g.user["id"]
    peer = q("select * from users where id=?", (uid,), one=True) or abort(404)
    if uid == me: return redirect(url_for("inbox"))
    if request.method == "POST":
        body = request.form.get("body", "").strip()[:2000]
        mid = run("insert into messages(sender,receiver,body) values(?,?,?)", (me, uid, body)) if body else 0
        if request.headers.get("X-Requested-With"):
            return jsonify(id=mid, body=body, mine=True, utc=time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime()))
        return redirect(url_for("thread", uid=uid))
    run("update messages set seen=1 where sender=? and receiver=?", (uid, me))
    msgs = q("select * from messages where (sender=? and receiver=?) or (sender=? and receiver=?) order by id", (me, uid, uid, me))
    pid = toint(request.args.get("project"), 0, 0, 10**9)
    read = q("select coalesce(max(id),0) m from messages where sender=? and receiver=? and seen=1", (me, uid), one=True)["m"]
    return render_template("thread.html", peer=peer, msgs=msgs, read_upto=read, project=q("select * from projects where id=?", (pid,), one=True))

@app.get("/api/messages/<int:uid>")
@login_required
def api_messages(uid):
    me = g.user["id"]; after = toint(request.args.get("after"), 0, 0, 10**12)
    rows = q("select * from messages where id>? and ((sender=? and receiver=?) or (sender=? and receiver=?)) order by id", (after, uid, me, me, uid))
    run("update messages set seen=1 where sender=? and receiver=?", (uid, me))
    read = q("select coalesce(max(id),0) m from messages where sender=? and receiver=? and seen=1", (me, uid), one=True)["m"]
    return jsonify(messages=[dict(id=r["id"], body=r["body"], mine=r["sender"] == me, utc=r["created"]) for r in rows], read_upto=read)

@app.get("/api/notify")
@login_required
def api_notify():
    """Polled every few seconds from every page: unread count + brand-new incoming messages (for pop-up alerts)."""
    me = g.user["id"]; after = toint(request.args.get("after"), 0, 0, 10**12)
    new = q("select m.id, m.sender, m.body, u.name from messages m join users u on u.id=m.sender "
            "where m.receiver=? and m.id>? order by m.id limit 5", (me, after))
    count = q("select count(*) c from messages where receiver=? and seen=0", (me,), one=True)["c"] + \
            q("select count(*) c from members where user_id=? and status='invited'", (me,), one=True)["c"]
    newest = q("select coalesce(max(id),0) m from messages where receiver=?", (me,), one=True)["m"]
    return jsonify(count=count, newest=newest, new=[dict(id=r["id"], sender=r["sender"], name=r["name"], body=r["body"][:90]) for r in new])

@app.post("/api/extract")
@login_required
def api_extract():
    skills, ai = extract_skills(request.form.get("idea", "")[:1500])
    return jsonify(skills=skills, ai=ai)

@app.post("/api/opener")
@login_required
def api_opener():
    to = q("select * from users where id=?", (toint(request.form.get("to"), 0, 0, 10**9),), one=True) or abort(404)
    p = q("select * from projects where id=?", (toint(request.form.get("project"), 0, 0, 10**9),), one=True)
    fills = []
    if p:
        needs = {n["skill"] for n in q("select skill from needs where project_id=?", (p["id"],))}
        fills = [s["skill"] for s in q("select skill from user_skills where user_id=?", (to["id"],)) if s["skill"] in needs]
    return jsonify(text=draft_opener(g.user["name"], to, p, fills))

@app.post("/api/stack")
@login_required
def api_stack():
    f = request.form
    return jsonify(suggest_stack(f.get("title", "").strip()[:90], f.get("idea", "")[:1500], f.get("sector", "Other")))

@app.post("/projects/<int:pid>/stack")
@login_required
def regen_stack(pid):
    p = get_project(pid)
    if p["owner_id"] != g.user["id"]: abort(403)
    d = suggest_stack(p["title"], p["pitch"], p["sector"])
    run("update projects set stack=? where id=?", (json.dumps(d), pid))
    flash("Tech stack updated." if d["ai"] else "The AI was unavailable, so this stack comes from simple rules. " + (d["error"] or ""))
    return redirect(url_for("project", pid=pid))

@app.route("/ai-check")
def ai_check():
    key = os.environ.get("GROQ_API_KEY", "")
    reply = groq([{"role": "user", "content": "Reply with the single word: ready"}], max_tokens=10)
    return render_template("aicheck.html", hint=(key[:4] + "..." + key[-4:]) if len(key) > 8 else None,
                           source=ENV_SOURCE, reply=reply, error=AI_LAST["error"], log=AI_LAST["log"], base=BASE)

init_db()
if __name__ == "__main__":
    app.run(debug=True)

"""Optional demo data: python seed.py  (log in as any seeded user with password demo1234)"""
import app
from werkzeug.security import generate_password_hash as h

USERS = [("Aarav Patel", "aarav@demo.in", "A.V.P.T.I. Rajkot", 8, "python:3, backend:2, databases:2"),
         ("Riya Shah", "riya@demo.in", "A.V.P.T.I. Rajkot", 10, "ui design:3, ux design:2, frontend:2"),
         ("Kabir Mehta", "kabir@demo.in", "L.D. College, Ahmedabad", 6, "marketing:3, content writing:2"),
         ("Meera Joshi", "meera@demo.in", "Marwadi University", 12, "machine learning:2, python:2, data analysis:3"),
         ("Dev Trivedi", "dev@demo.in", "A.V.P.T.I. Rajkot", 5, "mobile development:2, frontend:1")]
PROJECTS = [(0, "Mess Meal Planner", "Hostel mess food is wasted every day because nobody knows how many students will eat. Students mark meals and the mess plans quantities.",
             "Food & delivery", "backend:2, ui design:2, marketing:1, mobile development:1"),
            (3, "Crop Doctor", "Small farmers cannot identify leaf diseases early. A photo goes in and a simple treatment tip comes out in Gujarati.",
             "Health", "machine learning:2, mobile development:2, frontend:1")]
with app.app.app_context():
    if not app.q("select 1 from users limit 1", one=True):
        ids = []
        for n, e, c, hrs, sk in USERS:
            uid = app.run("insert into users(name,email,pw,college,hours) values(?,?,?,?,?)", (n, e, h("demo1234"), c, hrs)); ids.append(uid)
            for s, l in app.parse_skills(sk): app.run("insert into user_skills values(?,?,?)", (uid, s, l))
        for o, t, p, sec, needs in PROJECTS:
            pid = app.run("insert into projects(owner_id,title,pitch,sector) values(?,?,?,?)", (ids[o], t, p, sec))
            for s, l in app.parse_skills(needs): app.run("insert into needs values(?,?,?)", (pid, s, l))
            app.run("insert into members values(?,?,'joined')", (pid, ids[o]))
        print("Seeded", len(ids), "users and", len(PROJECTS), "projects.")
    else: print("Database already has data; skipped.")

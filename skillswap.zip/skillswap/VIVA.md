# Interview Q&A

**What problem does it solve?** Students have ideas but cannot find teammates with the right skills. SkillSwap matches people to the gaps in a team.

**How does the matching work?** Rule-based scoring: skill presence, skill level against the required level, and weekly availability. Skills already covered by the team are excluded, so it ranks people who add something new.

**Why not machine learning for matching?** There is no training data, and a rule-based score is transparent: I can show exactly why a person ranks where they do.

**What does the AI do?** Three small things: suggest skills from a pitch, draft a first message, and rewrite lessons from failed startups. If Groq is down or has no key, each feature has a non-AI fallback, so the app never breaks.

**How do you stop the AI inventing failed startups?** Groq only receives rows from my CSV and is told to use only those. The startup names come from the data, not the model.

**How are passwords stored?** Hashed with Werkzeug (`generate_password_hash`), never in plain text.

**What security measures did you add?** Password hashing, CSRF tokens on every POST, parameterised SQL queries (no SQL injection), the API key in `.env`, and safe redirect checks after login.

**How does chat work?** Messages are rows in SQLite. The page polls `/api/messages/<id>?after=<last_id>` every 4 seconds. WebSockets would be instant but polling is simpler and enough here.

**Describe your database.** `users` 1-many `user_skills`; `projects` 1-many `needs`; `members` links users and projects with a status; `messages` links sender and receiver.

**What was the hardest bug or decision?** Deciding who counts as "covering" a skill: I compute coverage from joined members only, so pending invites do not hide a gap.

**What would you improve?** College email verification, WebSocket chat, team milestones, reviews after a project, and a bigger failed-startup dataset.

**What are the limits?** Skill names are free text (aliases help but are not perfect), scoring ignores timezone and interests, and polling does not scale to thousands of users.

**What happens if the AI fails?** Every AI feature has a rule-based fallback (for example keyword rules for the tech stack), and the page tells the user why the AI was unavailable instead of failing silently.

**How do real-time messages work?** The browser asks `/api/notify` every 5 seconds (and the open chat asks `/api/messages` every 2.5 seconds) for anything newer than the last message id it has seen. Seen ticks come from a `seen` flag set when the receiver loads the messages.

**How does the theme switch work?** The colours are CSS variables. A `data-theme` attribute on the page switches the variable values, and the choice is saved in `localStorage`.

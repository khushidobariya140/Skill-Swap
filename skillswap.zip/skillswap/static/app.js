const CSRF = document.querySelector('meta[name=csrf]').content;
async function post(url, data) {
  const fd = new FormData(); for (const k in data) fd.append(k, data[k]);
  const r = await fetch(url, {method: 'POST', body: fd, headers: {'X-CSRF': CSRF, 'X-Requested-With': 'fetch'}});
  if (!r.ok) throw new Error('Request failed'); return r.json();
}
function mk(tag, txt, cls) { const e = document.createElement(tag); if (txt) e.textContent = txt; if (cls) e.className = cls; return e; }
// The server stores UTC; show every time in the viewer's own timezone.
function fmtTime(utc) {
  const d = new Date(String(utc).replace(' ', 'T') + 'Z'); if (isNaN(d)) return '';
  const t = d.toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'});
  return d.toDateString() === new Date().toDateString() ? t : d.toLocaleDateString([], {day: 'numeric', month: 'short'}) + ', ' + t;
}
function localizeTimes(root) { (root || document).querySelectorAll('time[data-utc]').forEach(t => t.textContent = fmtTime(t.dataset.utc)); }
localizeTimes();
(function () {   // light / dark switch (the starting theme is set by a tiny script in <head>)
  const btn = document.getElementById('theme'), root = document.documentElement; if (!btn) return;
  const sync = () => btn.setAttribute('aria-pressed', root.dataset.theme === 'dark'); sync();
  btn.onclick = () => { const n = root.dataset.theme === 'dark' ? 'light' : 'dark'; root.dataset.theme = n;
    try { localStorage.setItem('theme', n); } catch (_) {} sync(); };
})();
(function () {   // live notifications: badge in the nav + a pop-up when a new message arrives
  const b = document.body; if (!b.dataset.user) return;
  let after = +b.dataset.last || 0; const badge = document.getElementById('nbadge'), box = document.getElementById('toasts'), base = document.title;
  function setBadge(n) { badge.textContent = n; badge.hidden = !n; document.title = n ? `(${n}) ${base}` : base; }
  function toast(m) { const a = mk('a', '', 'toast'); a.href = '/messages/' + m.sender;
    a.append(mk('b', m.name + ' sent you a message'), mk('span', m.body)); box.append(a); setTimeout(() => a.remove(), 7000); }
  async function tick() {
    if (document.hidden) return;
    try { const r = await (await fetch('/api/notify?after=' + after)).json(); setBadge(r.count);
      r.new.forEach(m => { if (location.pathname !== '/messages/' + m.sender) toast(m); }); after = Math.max(after, r.newest); } catch (_) {}
  }
  setInterval(tick, 5000);
})();
